from django.apps import AppConfig


class NontrivialappConfig(AppConfig):
    name = 'nonTrivialApp'
