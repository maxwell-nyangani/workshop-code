from django.contrib import admin
from nonTrivialApp.models import Store

# Register your models here.
admin.site.register(Store)
